from django.contrib import admin

from htmlwebsite.models import Contact
admin.site.register(Contact)


