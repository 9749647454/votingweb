from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
def website(request):
    #  return  HttpResponse("hi welcome to the html website page ")
    return render(request,'index.html')

