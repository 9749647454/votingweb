from django.db import models

# Create your models here.

class Candidates(models.Model):
    IDno = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    post = models.CharField(max_length=100)
    party  = models.CharField(max_length=100)
    consituency = models.CharField(max_length=100)

    class VOTERS(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    area = models.CharField(max_length=100)
    age = models.CharField(max_length=100)




  