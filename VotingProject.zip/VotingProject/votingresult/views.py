

from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
def result(request):
     return  HttpResponse("hi welcome to the votingresult page and the winner is to be annound soon")


