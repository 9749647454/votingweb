from django.db import models

# Create your models here.

class Contact(models.Model):
    sno = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    phone = models.CharField(max_length=100)
    address = models.CharField(max_length=100)
    
class candidates(models.Model):
    sno = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    partyname = models.CharField(max_length=100)
    phone = models.CharField(max_length=100)
    consituency = models.CharField(max_length=100)
    





