from django.http import HttpResponse
from django.shortcuts import render
from htmlwebsite.models import  Contact

# Create your views here.
def website(request):
    contactdata = Contact.objects.all()
    for a in contactdata:
        print(a.address)

     


    if request.method=='POST':
        contact = Contact()
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        address = request.POST.get('address')
        contact.name=name
        contact.email=email
        contact.phone=phone
        contact.address=address
        contact.save()
        return HttpResponse("you are registered successyfully for online voting ")
        return HttpResponse(" please go to info page for furthur information ")
    
    #  return  HttpResponse("hi welcome to the html website page ")
    return render(request,'indexa.html.')
def homepage(request):
    return render(request,'indexa.html')

def votingresult(request):
    return render(request,'mypage2.html')