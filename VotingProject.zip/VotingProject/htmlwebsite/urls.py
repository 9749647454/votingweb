from django.contrib import admin
from django.urls import include, path
from htmlwebsite import views
app_name='htmlwebsite'

urlpatterns = [
     path('', views.website, name='website'),
    path('homePage', views.homepage, name='homepage'),
path('votingresult', views.votingresult, name='votingresult'),
]


